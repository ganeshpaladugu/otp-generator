# OTP-GENERATOR-AND-VERIFICATION
A project based in java which generates and verifies otp , from users.
